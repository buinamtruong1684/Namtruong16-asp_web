﻿namespace BaiTapKiemTra01
{
    public class SanPhamViewModel
    {
        public string TenSanPham { get; set; }
        public string GiaBan { get; set; }

        public string AnhMoTa { get; set; }

        public int Age { get; set; }
    }
}
